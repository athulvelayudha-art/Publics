OFFLINE GRID NAVIGATOR - IPHONE WEB APP PROTOTYPE

1. Upload all three files together to an HTTPS web host (e.g. GitHub Pages, Netlify).
2. Open the HTTPS address in Safari on your iPhone, allow Location, tap Share > Add to Home Screen.
3. While online, visit and zoom into map areas needed later. Tiles displayed are saved to browser cache when available.
4. Test with Airplane Mode BEFORE travelling. Safari can evict cached map tiles.
5. GPS location may work without mobile data, provided satellite signals and iOS location permission are available.

INCLUDED: GPS, WGS84 decimal/DMS/DM, UTM, MGRS, accuracy, altitude, speed, heading, true bearing, straight-line distance, manually entered decimal-degree destination, saved waypoints and export, offline cached viewed OSM tiles.
NOT INCLUDED: Google/Esri satellite imagery downloads, complete AlpineQuest map catalogs, Kalianpur 1880 datum transformations, full offline region downloads, military grid formats other than WGS84 UTM/MGRS, native iOS app.
IMPORTANT: Never use this prototype as a sole source for safety-critical navigation or precision survey.
